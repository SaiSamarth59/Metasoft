import express from 'express';
import cors from 'cors';
import fs from 'fs/promises'; // Import Node.js File System module

const app = express();
const PORT = 4000;
const DB_FILE = './db.json'; // Define the path to our database file

let db = {
  feedback: [],
  currentId: 1
};

// --- Database Loading Function ---
async function loadDatabase() {
  try {
    const data = await fs.readFile(DB_FILE, 'utf-8');
    db = JSON.parse(data);
    console.log('✅ Database loaded successfully.');
  } catch (error) {
    if (error.code === 'ENOENT') {
      console.log('No database file found. A new one will be created on save.');
    } else {
      console.error('Error loading database:', error);
    }
  }
}

// --- Database Saving Function ---
async function saveDatabase() {
  try {
    const data = JSON.stringify(db, null, 2); // Pretty-print JSON
    await fs.writeFile(DB_FILE, data, 'utf-8');
    console.log('💾 Database saved.');
  } catch (error) {
    console.error('Error saving database:', error);
  }
}

app.use(cors());
app.use(express.json());

// --- GET Endpoint (No change needed) ---
app.get('/feedback', (req, res) => {
  console.log('GET /feedback - Sending feedback list');
  res.json(db.feedback);
});

// --- POST Endpoint (THIS IS THE UPDATED CODE) ---
app.post('/feedback', async (req, res) => {
  // Destructure the new data model from the Figma form
  const {
    visitFrequency,
    foodRating,
    serviceRating,
    overallRating,
    recommend,
    suggestions,
    followUp,
    name,
    email
  } = req.body;

  // --- New Validation Logic ---
  // It now checks for the new rating fields
  if (!foodRating || !serviceRating || !overallRating) {
    return res.status(400).json({ message: 'Missing required star ratings.' });
  }

  // It also checks for name/email *if* followup is true
  if (followUp && (!name || !email)) {
    return res.status(400).json({ message: 'Name and Email are required for follow-up.' });
  }

  const newFeedback = {
    id: db.currentId++,
    visitFrequency,
    foodRating,
    serviceRating,
    overallRating,
    recommend,
    suggestions,
    followUp,
    name: followUp ? name : '',
    email: followUp ? email : ''
  };

  db.feedback.push(newFeedback);
  
  await saveDatabase();
  
  console.log('POST /feedback - Added new cafe survey feedback:');
  console.log(newFeedback);
  
  res.status(201).json(newFeedback); 
});

// --- DELETE Endpoint (No change needed) ---
app.delete('/feedback', async (req, res) => {
  console.log('DELETE /feedback - Clearing all feedback');
  db.feedback = [];
  db.currentId = 1; 
  await saveDatabase();
  console.log('ID counter reset to 1');
  res.status(200).json({ message: 'All feedback cleared and ID counter reset' });
});

// --- Server Start (No change needed) ---
(async () => {
  await loadDatabase(); // Load the database first
  
  app.listen(PORT, () => {
    console.log(`✅ Feedback server is running at http://localhost:${PORT}`);
  });
})();