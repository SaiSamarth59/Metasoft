const express = require('express');
const router = express.Router();
const db = require('../db');
const logger = require('../logger');

// Validation helper (simple)
function validatePayload(body) {
  const { name, email, rating } = body;
  if (!name || !email) return { ok: false, msg: 'name and email required' };
  if (rating === undefined || rating === null) return { ok: false, msg: 'rating required' };
  if (Number.isNaN(Number(rating)) || rating < 1 || rating > 5) return { ok: false, msg: 'rating must be 1-5' };
  return { ok: true };
}

// POST /api/feedback
router.post('/', (req, res, next) => {
  try {
    const validation = validatePayload(req.body);
    if (!validation.ok) return res.status(400).json({ error: validation.msg });

    const { name, email, rating, comments = '' } = req.body;
    const stmt = db.prepare('INSERT INTO feedback (name, email, rating, comments) VALUES (?, ?, ?, ?)');
    const info = stmt.run(name, email, rating, comments);

    logger.info('New feedback inserted id=%d email=%s', info.lastInsertRowid, email);
    return res.status(201).json({ id: info.lastInsertRowid });
  } catch (err) {
    logger.error('Error in POST /api/feedback: %o', err);
    next(err);
  }
});

// GET /api/feedback
router.get('/', (req, res, next) => {
  try {
    const stmt = db.prepare('SELECT id, name, email, rating, comments, created_at FROM feedback ORDER BY created_at DESC');
    const rows = stmt.all();
    res.json(rows);
  } catch (err) {
    logger.error('Error in GET /api/feedback: %o', err);
    next(err);
  }
});

module.exports = router;
