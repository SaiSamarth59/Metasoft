import React, { useEffect, useState } from "react";
import axios from "axios";

export default function Dashboard() {
  const API = "http://localhost:4000";
  const [rows, setRows] = useState([]);
 
  const [errorMessage, setErrorMessage] = useState("");
  const [isLoading, setIsLoading] = useState(true);

  async function load() {
    setIsLoading(true);
    setErrorMessage(""); 
    try {
      const res = await axios.get(`${API}/feedback`);
      setRows(res.data);
    } catch (error) {
      console.error("Error loading dashboard data:", error);
      setErrorMessage("Could not load data. Is the server running?");
    } finally {
      setIsLoading(false);
    }
  }

  async function clearAll() {
    setErrorMessage("");
    if (!window.confirm("Are you sure you want to delete all feedback? This cannot be undone.")) {
      return;
    }
    
    try {
      await axios.delete(`${API}/feedback`);
      load(); 
    } catch (error) {
      console.error("Error clearing data:", error);
      setErrorMessage("Could not clear data. Please try again.");
    }
  }

  useEffect(() => {
    load();
  }, []);

  return (
    // This class centers the dashboard on the page
    <div className="table-container"> 
      <div className="table-header">
        <h2>Feedback Dashboard</h2>
        <button onClick={clearAll} className="clear-button">Clear All Feedback</button>
      </div>

      {errorMessage && (
        <div className="message error" style={{ marginBottom: '1rem' }}>
          {errorMessage}
        </div>
      )}

      {/* This wrapper makes the table scrollable on small screens */}
      <div className="table-scroll-wrapper">
        <table>
          {/* --- THESE ARE THE 9 NEW TABLE HEADERS --- */}
          <thead>
            <tr>
              <th>ID</th>
              <th>Food</th>
              <th>Service</th>
              <th>Overall</th>
              <th>Recommend</th>
              <th>Visit Freq.</th>
              <th>Follow Up</th>
              <th>Suggestions</th>
              <th>Contact</th>
            </tr>
          </thead>

          <tbody>
            {isLoading ? (
              <tr>
                <td colSpan="9" style={{ textAlign: 'center' }}>Loading...</td>
              </tr>
            ) : rows.length === 0 ? (
              <tr>
                <td colSpan="9" style={{ textAlign: 'center' }}>No feedback yet.</td>
              </tr>
            ) : (
              // --- THIS DISPLAYS THE 9 NEW DATA FIELDS ---
              rows.map((r) => (
                <tr key={r.id}>
                  <td>{r.id}</td>
                  <td>{r.foodRating} ⭐</td>
                  <td>{r.serviceRating} ⭐</td>
                  <td>{r.overallRating} ⭐</td>
                  <td>{r.recommend || '-'}</td>
                  <td>{r.visitFrequency || '-'}</td>
                  <td>{r.followUp ? 'Yes' : 'No'}</td>
                  <td className="suggestions-cell">{r.suggestions || '-'}</td>
                  <td>{r.followUp ? r.email : '-'}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}