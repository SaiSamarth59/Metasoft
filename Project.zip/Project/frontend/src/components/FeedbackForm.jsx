import React, { useState, useEffect } from "react";
import axios from "axios";
import StarRating from "./StarRating"; // Your existing StarRating component

// --- Default State for the new form ---
const initialFormState = {
  visitFrequency: "Regularly",
  foodRating: 0,
  serviceRating: 0,
  overallRating: 0,
  recommend: "",
  suggestions: "",
  followUp: false,
  name: "",
  email: ""
};

export default function FeedbackForm() {
  const API = "http://localhost:4000";
  const [data, setData] = useState(initialFormState);
  const [message, setMessage] = useState({ text: "", type: "" });
  
  // --- NEW: State to show Thank You page ---
  const [isSubmitted, setIsSubmitted] = useState(false);

  // --- Generic Change Handler ---
  function handleChange(e) {
    const { name, value, type, checked } = e.target;
    setData({
      ...data,
      [name]: type === "checkbox" ? checked : value
    });
  }

  // --- Specific Handlers for Star Ratings ---
  function handleFoodRating(rating) {
    setData({ ...data, foodRating: rating });
  }
  function handleServiceRating(rating) {
    setData({ ...data, serviceRating: rating });
  }
  function handleOverallRating(rating) {
    setData({ ...data, overallRating: rating });
  }

  // --- Form Submission ---
  async function submitForm(e) {
    e.preventDefault();
    
    // --- Validation ---
    if (data.foodRating === 0 || data.serviceRating === 0 || data.overallRating === 0) {
      setMessage({ text: "Please provide all three star ratings.", type: "error" });
      return;
    }
    if (data.recommend === "") {
        setMessage({ text: "Please let us know if you would recommend us.", type: "error" });
        return;
    }
    if (data.followUp && (!data.name || !data.email)) {
        setMessage({ text: "Please provide your name and email for follow-up.", type: "error" });
        return;
    }

    setMessage({ text: "", type: "" });
    
    try {
      await axios.post(`${API}/feedback`, data);
 
      // --- NEW: Show the thank you page ---
      setIsSubmitted(true);
      
      // Reset the form data
      setData(initialFormState);

    } catch (error) {
      console.error("Error submitting feedback:", error);
      const errorText = error.response?.data?.message || "Failed to submit feedback.";
      setMessage({ text: errorText, type: "error" });
    }
  }

  // --- NEW: Function to reset the form ---
  function handleSubmitAnother() {
    setIsSubmitted(false);
    setMessage({ text: "", type: "" });
  }

  // --- Message Timeout Effect (No change) ---
  useEffect(() => {
    if (message.text && !isSubmitted) { // Only run timer if not on thank you page
      const timer = setTimeout(() => {
        setMessage({ text: "", type: "" });
      }, 4000);
      return () => clearTimeout(timer); 
    }
  }, [message, isSubmitted]);

  // --- NEW: Thank You Page View ---
  if (isSubmitted) {
    return (
      <div className="form-container form-container-figma" style={{ textAlign: 'center', padding: '3rem' }}>
        <svg className="success-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" fill="var(--success)">
          <path d="M256 0C114.6 0 0 114.6 0 256s114.6 256 256 256s256-114.6 256-256S397.4 0 256 0zM371.8 211.8l-128 128C238.3 345.3 231.2 348 224 348s-14.3-2.7-19.8-8.2l-64-64c-10.9-10.9-10.9-28.7 0-39.6s28.7-10.9 39.6 0l44.2 44.2l108.2-108.2c10.9-10.9 28.7-10.9 39.6 0s10.9 28.7 0 39.6z"/>
        </svg>
        <h2 style={{ marginTop: '1.5rem', color: 'var(--dark-text)' }}>Thank You!</h2>
        <p style={{ color: 'var(--gray-text)', marginTop: '0.5rem', lineHeight: '1.6' }}>
          Your feedback has been submitted successfully.
        </p>
        <button 
          onClick={handleSubmitAnother} 
          className="btn-submit" 
          style={{ width: 'auto', padding: '12px 24px', marginTop: '2rem' }}
        >
          Submit Another
        </button>
      </div>
    );
  }

  // --- Original Form View ---
  return (
    // Use 'form-container-figma' for new styles
    <div className="form-container form-container-figma">
      
      {/* --- Figma Header --- */}
      <img 
        src="https://placehold.co/150x60/FFFFFF/333333?text=UNIWELL" 
        alt="Uniwell Logo" 
        className="form-logo"
      />
      <img 
        src="/cafe-banner.png" /* Make sure this path is in your /public folder */
        alt="Cafe Banner" 
        className="form-banner"
      />
      
      <div className="form-header-text">
        <h3>HELLO, THANKS FOR VISITING</h3>
        <p>Please help us improve our cafe services by filling in our feedback form. Thank you!</p>
      </div>

      {/* Message Display Area */}
      {message.text && (
        <div className={`message ${message.type}`}>
          {message.text}
        </div>
      )}

      {/* --- New Figma Form --- */}
      <form onSubmit={submitForm} className="figma-form">
        
        <div className="form-group">
          <label>How often do you visit here?</label>
          <select 
            name="visitFrequency" 
            value={data.visitFrequency} 
            onChange={handleChange}
          >
            <option>Regularly</option>
            <option>Sometimes</option>
            <option>Once</option>
          </select>
        </div>

        <div className="form-group">
          <label>Quality of the food</label>
          <StarRating rating={data.foodRating} setRating={handleFoodRating} />
        </div>

        <div className="form-group">
          <label>Service Quality</label>
          <StarRating rating={data.serviceRating} setRating={handleServiceRating} />
        </div>

        <div className="form-group">
          <label>Overall Experience</label>
          <StarRating rating={data.overallRating} setRating={handleOverallRating} />
        </div>

        <div className="form-group">
          <label>Would you recommend our restaurant to others?</label>
          <div className="radio-group">
            <label>
              <input 
                type="radio" 
                name="recommend" 
                value="Yes" 
                checked={data.recommend === "Yes"} 
                onChange={handleChange} 
              />
              Yes
            </label>
            <label>
              <input 
                type="radio" 
                name="recommend" 
                value="No" 
                checked={data.recommend === "No"} 
                onChange={handleChange} 
              />
              No
            </label>
          </div>
        </div>

        <div className="form-group">
          <label>Your suggestions to improve</label>
          <textarea
            name="suggestions"
            placeholder="Your suggestions..."
            value={data.suggestions}
            onChange={handleChange}
          ></textarea>
        </div>

        <div className="form-group-checkbox">
          <label>
            <input 
              type="checkbox"
              name="followUp"
              checked={data.followUp}
              onChange={handleChange}
            />
            Receive personal follow up to your feedback
          </label>
        </div>

        {/* --- Conditional Fields --- */}
        {data.followUp && (
          <div className="follow-up-fields">
            <div className="form-group">
              <label>Your Name</label>
              <input
                type="text"
                name="name"
                placeholder="Your Name"
                value={data.name}
                onChange={handleChange}
              />
            </div>
            <div className="form-group">
              <label>Email</label>
              <input
                type="email"
                name="email"
                placeholder="Email"
                value={data.email}
                onChange={handleChange}
              />
            </div>
          </div>
        )}

        <button type="submit" className="btn-submit">Submit Feedback</button>
      </form>
    </div>
  );
}