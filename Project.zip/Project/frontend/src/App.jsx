import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
// Assuming your components are in a 'components' folder
// If they are in the same folder as App.jsx, remove "components/"
import FeedbackForm from "./components/FeedbackForm";
import Dashboard from "./components/Dashboard";

export default function App() {
  return (
    <BrowserRouter>
      <nav className="navbar">
        {/* This container centers your links */}
        <div className="nav-container">
          <Link to="/">Feedback</Link>
          <Link to="/dashboard">Dashboard</Link>
        </div>
      </nav>

      <Routes>
        <Route path="/" element={<FeedbackForm />} />
        <Route path="/dashboard" element={<Dashboard />} />
      </Routes>
    </BrowserRouter>
  );
}